﻿using System.Windows.Forms;

namespace PCB_TPL_Fitxers
{
    public partial class frmTPL : Form
    {
        public frmTPL()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
        }

        

    }
}
