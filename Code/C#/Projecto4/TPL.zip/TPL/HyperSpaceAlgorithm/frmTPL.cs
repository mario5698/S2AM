﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TPL
{
    public partial class frmTPL : Form
    {
        public frmTPL()
        {
            InitializeComponent();
        }

        private void cmdCheck_Click(object sender, EventArgs e)
        {
             // Cal fer una crida a StartProcess() utilitzant una tasca
        }

        private void StartProcess()
        {
            string[] nomFitxer = { "1.txt", "2.txt", "3.txt" };
            //Per a cada fitxer cal fer una crida en paral·lel a la funció DoChecks passant a part de 
            // l'array de strings també el control on volem pintar els resultats
        }


        private void DoChecks(string[] words, ListBox lst)
        {
            //aquí llençarem en paral·lel cadascuna de les tasques a fer en el Helper

            //Utilitzem aquests arrays per indicar quines paraules volem buscar i quina lletra 
            //Això serà necessariper alguns mètodes
            string[] Searchwords = { "white", "time", "that", "the", "empty", "door", "table" };
            string[] SearchLetter = { "A", "C", "W", "Z", "L", "S", "E" };
                       
            Random rnd = new Random();     // servirà més tard per trobar a l'atzar la llargada d'algunes paraules

            
           
        }


        #region HelperMethods


        private string  GetLongestWord(string[] words)
        {
            //cerca la paraula més llarga del llibre

            string resultat="";
            return resultat;
 
        }


        private string GetMostCommonWords(string[] words, int len,  int quants)
        {

            // cerca les paraules que apareixen més cops d'una determinada llargada i ens mostren quines són i quants cops apareixen
            // l'argument quants indica quantes paraules hem de mostrar Si indiquem 5 vol dir que mostrem les 5 que surten més
            // per defecte passem sempre 5
            // l'argument len indica la llargada de les paraules i s'obtindrà a partir d'obtenir 
            // un nombre random entre 4 i 10 a la funció que fa la crida a aquesta

            string resultat = "";
            return resultat;
        }


        private string GetMostCommonWordsByLength(string[] words, int len, int quants)
        {
            // cerca les paraules que apareixen més cops d'una determinada llargada i ens mostren quines són i quants cops apareixen
            // l'argument quants indica quantes paraules hem de mostrar Si indiquem 5 vol dir que mostrem les 5 que surten més
            // per defecte passem sempre 5
            // l'argument len indica la llargada de les paraules i s'obtindrà a partir d'obtenir un nombre random entre 4 i 10 a la funció que fa la crida a aquesta

            string resultat = "";
            return resultat;

        }

        private string GetCountForWord(string[] words, string term)
        {
            // cerca quants cops apareix la paraula term en el llibre
            // l'argument term és cadascuna de les paraules que hi ha en l'array de paraules de DoChecks

            string resultat = "";
            return resultat;


        }

        private string GetCountForLetter(string[] words, string letter)
        {
            // cerca quants cops apareixen paraules que comencen amb la lletra indicada a l'argument letter 
            // l'argument letter és cadascuna de les lletres que hi ha en l'array de lletres de  DoChecks

            string resultat = "";
            return resultat;


        }



        private string  GetLessCommonWords(string[] words, int len, int quants)
        {
            // cerca quants cops apareixen les paraules que menys apareixen i que tenen una determinada llargada
            // l'argument quants indica quantes paraules hem de mostrar. Si indiquem 5 vol dir que mostrem les 5 que surten menys
            // per defecte passem sempre 5 
            // l'argument len indica la llargada de les paraules i s'obtindrà a partir d'obtenir 
            // un nombre random entre 4 i 10 a la funció que fa la crida a aquesta

            string resultat = "";
            return resultat;



        }

        ///Falten les funcions que llegeixen el fitxer i en darrer cas el transformen en un array de strings amb les paraules. 
        ///Podeu utilitzar la funció de l'exemple com a base (CreateWordArray), però penseu que ara els fitxers són locals i no  una URL,
        ///i que potser caldrà fer-ho d'una forma una mica diferent per afavorir automatitzar el programa.



        #endregion








    }
}
