﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaRefactoring
{
    public class Detall
    {
        public string Producte { get; set; }
        public int quantitat { get; set; }
        public double preu { get; set; }
    }
}
