# login_minimalist_flutter

Login minimalist using framework flutter.

Cretids design: https://www.behance.net/gallery/88214279/Sign-InSing-Up?tracking_source=search%7Clogin%20ui

![6f30cb88214279 5dcf3fff0b4f0](https://user-images.githubusercontent.com/54786785/75627922-397d2d80-5bb3-11ea-8723-5e1fa66190de.png)

![minimalist2](https://user-images.githubusercontent.com/54786785/75636744-2775ac00-5c00-11ea-9421-ba1f32f2243f.jpeg)

![minimalist1](https://user-images.githubusercontent.com/54786785/75636732-09a84700-5c00-11ea-99f4-300b8886d175.jpeg)

